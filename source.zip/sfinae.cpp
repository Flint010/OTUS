#include <string>
#include <type_traits>

struct SomeStruct {
    SomeStruct(const char* v): m_value(v) {};
    SomeStruct(const std::string& v): m_value(v) {};
    SomeStruct(std::string&& v): m_value(std::move(v)) {};

	SomeStruct(const SomeStruct &other): m_value{other.m_value} {}

    /*template <class T>
    SomeStruct(T&& t): m_value(std::forward<T>(t)) {}*/

    /*template <typename TT,
              typename Enable =
                  typename std::enable_if<
                      !std::is_same<typename std::remove_reference<TT>::type,
                                    SomeStruct>::value,
                      void>::type>
    SomeStruct(TT &&value) : m_value{std::forward<TT>(value)} {
    }*/

	const std::string& getValue() const {
		return m_value;
	}

private:
	std::string m_value;
};

int main() {
	SomeStruct first("Hello, World!");
	SomeStruct second = first;
}

#include <type_traits>
#include <iostream>

struct Pt {
    int x{42};
};

struct Point {
    inline int x() const { return 42; };
};

template<typename T>
struct has_x_method {
    template<typename U>
    static decltype(U().x()) detect(const U&);
    static std::nullptr_t detect(...);
    static constexpr bool value = true;
};

int main() {
    std::cout << "Pt has x() " << std::boolalpha << has_x_method<Pt>::value << std::endl
        << "Point has x() " << std::boolalpha << has_x_method<Point>::value << std::endl;
}

/*template<typename T>
struct has_x_method {
    template<typename U>
    static decltype(std::declval<U>().x()) detect(const U&);
    static std::nullptr_t detect(...);
    static constexpr bool value = !std::is_same<std::nullptr_t, decltype(detect(std::declval<T>()))>::value;
};*/